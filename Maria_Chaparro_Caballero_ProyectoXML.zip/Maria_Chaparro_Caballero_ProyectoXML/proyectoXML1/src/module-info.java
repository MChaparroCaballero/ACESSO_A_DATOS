/**
 * 
 */
/**
 * 
 */
module proyectoXML1 {
	requires java.xml;
}